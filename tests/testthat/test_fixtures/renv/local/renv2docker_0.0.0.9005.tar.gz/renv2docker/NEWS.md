# renv2docker 0.0.0.9005

New README

- Fixed: switched from `usethis:::project_data()` to
`usethis:::ppackage_data()`. Still not a reliable base, though, as this is still
an internal function => TODO: get rid of this dependency

-------------------------------------------------------------------------------

# renv2docker 0.0.0.9004

Parameterized docker images

- Added functionality for parameterized docker 
- Refactored environment variable creation

--------------------------------------------------------------------------------

# renv2docker 0.0.0.9004

Templates

- Added dev dependency: `rappster/renvx`
- Added templating functionality

--------------------------------------------------------------------------------

# renv2docker 0.0.0.9003

- Added package dependency: `here`
- Changed `Filesystem` to `Local`

--------------------------------------------------------------------------------

# renv2docker 0.0.0.9002

Renamed functions & devtools

- Renamed functions
- Added package dependency: `devtools`

--------------------------------------------------------------------------------

# renv2docker 0.0.0.9001

Fixed export

--------------------------------------------------------------------------------

# renv2docker 0.0.0.9000

Initial commit
