# $(grep -v '^#' .env | xargs) echo
source .env
echo $HELLO
echo $WORLD
