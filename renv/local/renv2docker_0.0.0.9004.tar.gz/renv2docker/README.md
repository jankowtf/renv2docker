
<!-- README.md is generated from README.Rmd. Please edit that file -->

# renv2docker

<!-- badges: start -->

[![Lifecycle:
experimental](https://img.shields.io/badge/lifecycle-experimental-orange.svg)](https://www.tidyverse.org/lifecycle/#experimental)
[![CRAN
status](https://www.r-pkg.org/badges/version/renv2docker)](https://CRAN.R-project.org/package=renv2docker)
<!-- badges: end -->

Project-specific cache of `{renv}` dependencies in Docker workflows

## Motivation

Past me:

1.  I wanted to use `{renv}` in combination with Docker and didn’t yet
    know how to mount my local [`{renv}`
    cache](https://rstudio.github.io/renv/articles/renv.html#cache-1),
    so the build process took **much** longer than I was willing to wait
    ;-)

2.  This also happened at a time before
    [rocker](https://hub.docker.com/u/rocker) switched to Ubuntu as the
    underlying Linux OS (Thanks to [Eric
    Nantz](https://twitter.com/thercast?lang=en) for pointing that out
    in your [podcast](https://github.com/rpodcast/r_dev_projects)!.

    Before that (AFAIU and AFAIR) \[**TODO: Investigate this so I don’t
    tell incorrect stuff here**\], it could happen that the compilation
    process slightly differed between Ubuntu and Debian(?). So even
    though you might have properly mounted your local [`{renv}`
    cache](https://rstudio.github.io/renv/articles/renv.html#cache-1) so
    it was available at build time, the resulting builds might have been
    incompatible with your local Linux OS.

So I wanted to have a two-step process build process that reduces the
overall build time:

**STEP 1**

Build an image that handles all of my package dependencies.

It only builds the dependencies once or when it has to (that is whenever
my `renv.lock` is updated) and caches them back to a subdirectory within
my local package directory (`./renv/cache_docker` \[TODO: or was it
`./renv/cache` –&gt; review this\]) for future builds.

I called this image the **D**ependency **C**ache **M**anager (**DCM**).

**STEP 2**

Build the actual image

This image get access to the locally persisted `{renv}` cache from the
previous step as well as `./renv/local` (the place where your package’s
`.tar.gz` file is built to when you use the `build.R`; see below).

It calls `renv::restore()` which uses the cache and restores your
package by installing it from source.

## Installation

``` r
remotes::install_github("rappster/renv2docker")
```

## Usage

``` r
library(renv2docker)
```

1.  Create the necessary environment variables for Docker

``` r
write_env_vars()
#> ✓ Setting active project to '/media/janko/Shared/Code/R/Packages/renv2docker'
#>                                                            PACKAGE_NAME 
#>                                              "PACKAGE_NAME=renv2docker" 
#>                                                         PACKAGE_VERSION 
#>                                            "PACKAGE_VERSION=0.0.0.9004" 
#>                                                      PACKAGE_MAINTAINER 
#> "PACKAGE_MAINTAINER=Janko Thyson (janko.thyson@rappster.io) [aut, cre]" 
#>                                                            PACKAGE_PORT 
#>                                                     "PACKAGE_PORT=8000" 
#>                                                               R_VERSION 
#>                                                       "R_VERSION=4.0.3" 
#>                                                            RENV_VERSION 
#>                                                   "RENV_VERSION=0.12.5" 
#>                                                                DCM_NAME 
#>                                             "DCM_NAME=renv2docker_deps"
```

Technically, they are mostly used as `ARG`s instead of `ENV`s, but at
least for `PACKAGE_PORT` it would make sense to pass it on as e `ENV`.
Still learning about the nitty-gritty details ;-) See [Docker ARG, ENV
and .env - a Complete
Guide](https://vsupalov.com/docker-arg-env-variable-guide/) for more
details on this

1.  Generate `./Dockerfile` and `./renv/Dockerfile`

``` r
dockerfile <- use_template_dockerfile(open = FALSE)

readLines(dockerfile)
#>  [1] "# References"                                                                                          
#>  [2] "# Overall: https://cran.r-project.org/web/packages/renv/vignettes/docker.html"                         
#>  [3] "# Handling local sources: https://rstudio.github.io/renv/articles/local-sources.html"                  
#>  [4] "# Ignoring dev dependencies: https://rstudio.github.io/renv/articles/faq.html"                         
#>  [5] "# ARG for FROM: https://docs.docker.com/engine/reference/builder/#understand-how-arg-and-from-interact"
#>  [6] ""                                                                                                      
#>  [7] "ARG  R_VERSION"                                                                                        
#>  [8] "FROM rocker/r-ver:$R_VERSION"                                                                          
#>  [9] ""                                                                                                      
#> [10] "ARG PACKAGE_NAME"                                                                                      
#> [11] "ARG PACKAGE_VERSION"                                                                                   
#> [12] "ARG PACKAGE_MAINTAINER"                                                                                
#> [13] ""                                                                                                      
#> [14] "LABEL version=$PACKAGE_VERSION"                                                                        
#> [15] "LABEL maintainer=$PACKAGE_MAINTAINER"                                                                  
#> [16] ""                                                                                                      
#> [17] "# Install Linux libs ----------"                                                                       
#> [18] "RUN apt-get update && \\"                                                                              
#> [19] "  apt-get autoremove && \\"                                                                            
#> [20] "  apt-get autoclean && \\"                                                                             
#> [21] "  apt-get install \\"                                                                                  
#> [22] "  -y \\"                                                                                               
#> [23] "  --force-yes \\"                                                                                      
#> [24] "  -f \\"                                                                                               
#> [25] "  libsasl2-dev \\"                                                                                     
#> [26] "  libssl-dev \\"                                                                                       
#> [27] "  libcurl4 \\"                                                                                         
#> [28] "  libcurl4-openssl-dev \\"                                                                             
#> [29] "  libxml2-dev \\"                                                                                      
#> [30] "  libsodium-dev \\"                                                                                    
#> [31] "  libz-dev \\"                                                                                         
#> [32] "  zlib1g-dev"                                                                                          
#> [33] ""                                                                                                      
#> [34] "# Copy dependency cache ----------"                                                                    
#> [35] "#RUN echo $(ls -a -1)"                                                                                 
#> [36] "RUN mkdir -p /root/.local/share/renv"                                                                  
#> [37] "COPY renv/cache_docker/ /root/.local/share/renv"                                                       
#> [38] "RUN echo $(ls -a -1 /root/.local/share/renv)"                                                          
#> [39] ""                                                                                                      
#> [40] "# Copy service components ----------"                                                                  
#> [41] "WORKDIR /service"                                                                                      
#> [42] "RUN mkdir -p /service/logs"                                                                            
#> [43] "COPY renv.lock renv.lock"                                                                              
#> [44] "COPY renv/local renv/local"                                                                            
#> [45] "COPY renv/activate.R  renv/activate.R"                                                                 
#> [46] ""                                                                                                      
#> [47] "COPY DESCRIPTION_OUTER DESCRIPTION"                                                                    
#> [48] "COPY inst/main.R main.R"                                                                               
#> [49] "# COPY .Rprofile .Rprofile"                                                                            
#> [50] ""                                                                                                      
#> [51] "# Restore dependencies from cache ----------"                                                          
#> [52] "RUN R \\"                                                                                              
#> [53] "  -e 'options(\"repos\" = \"https://packagemana¸ger.rstudio.com/all/__linux__/focal/latest\")' \\"     
#> [54] "  -e 'source(\"renv/activate.R\")' \\"                                                                 
#> [55] "  -e 'Sys.setenv(RENV_PATHS_LOCAL=\"renv/local\")' \\"                                                 
#> [56] "  -e 'renv::restore()'"                                                                                
#> [57] ""                                                                                                      
#> [58] "# Serve microservice via API ----------"                                                               
#> [59] "CMD Rscript 'main.R'"
```

``` r
(use_template_dockerfile_dcm(open = FALSE))
#> /media/janko/Shared/Code/R/Packages/renv2docker/renv/Dockerfile
```

1.  Generate `docker_build.sh` and `docker_run.sh`

``` r
(use_template_docker_build(open = FALSE))
#> /media/janko/Shared/Code/R/Packages/renv2docker/docker_build.sh
```

``` r
(use_template_docker_run(open = FALSE))
#> /media/janko/Shared/Code/R/Packages/renv2docker/docker_run.sh
```

1.  Generate `build.R`

This template ensures that your package is built into `./renv/local` and
that all workflow requirements of `renv2docker` are met regarding the
caching of package dependency builds.

``` r
(use_template_build())
#> ✓ Leaving 'build.R' unchanged
#> /media/janko/Shared/Code/R/Packages/renv2docker/build.R
```

1.  Modify the desired R script to be run inside the Docker container

Find line

    COPY inst/main.R main.R

and line

    CMD Rscript 'main.R'

and adapt it to your setup.

The default setup

-   expects a file `main.R` within your `inst` directory
-   copies that into the Docker image as file `main.R`
-   Runs `main.R` via `Rscript`

1.  Build your Docker container

Open a terminal/shell within your package/project root directory and
type

    ./docker_build.sh

1.  Run your Docker container

<!-- -->

    ./docker_run.sh

## Shout outs

This package was inspired and influenced by

-   [Colin Fay: An Introduction to Docker for R
    Users](https://colinfay.me/docker-r-reproducibility/)
-   [ColinFay/dockerfiler](https://github.com/ColinFay/dockerfiler)
-   [ThinkR/devindocker](https://github.com/ThinkR-open/devindocker)
-   [Eric Nantz: R Dev
    Projects](https://github.com/rpodcast/r_dev_projects)

My goal is to align this package as much as I can with existing
workflows and best practices around R in combination with Docker.

## TODOs

-   Learn much more about Docker ;-)
-   Thoroughly investigate existing tooling around R and docker -
    especially the packages and workflows mentioned in the shout outs -
    to see where I can improve the package by better aligning it with
    best practices

## DISCLAIMER

This is another one of my “scratch your own itch” type of projects.

I use Linux ([Pop!\_OS](https://pop.system76.com/)) and hence aligned
`{renv}` and Docker workflows to that platform –&gt; not sure how much
of it is applicable for MacOS or Windows

Still hope it works for other developers out there as well :-)

## Code of Conduct

Please note that the renv2docker project is released with a [Contributor
Code of
Conduct](https://contributor-covenant.org/version/2/0/CODE_OF_CONDUCT.html).
By contributing to this project, you agree to abide by its terms.
