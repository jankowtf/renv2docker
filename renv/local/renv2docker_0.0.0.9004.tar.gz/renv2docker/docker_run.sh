docker run --rm --memory=650m --cpus="1" -p 127.0.0.1:8000:8000 -p 127.0.0.1:8001:8001 renv2docker
  # --env-file .env_prod_remote_atlas \
  # -v /home/data/Code/Rappster/Stadtsalat/dds.delivduration/service/logs:/service/logs \
  # --name renv2docker \

